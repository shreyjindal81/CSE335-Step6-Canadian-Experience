/**
 * Abstract base class for actor factories.
 * 
 *  filename "ActorFactory.h"
 * 
 * \author Shrey Jindal
 */
#pragma once


/**
 * Abstract base class for actor factories.
 */
class CActorFactory
{

};

